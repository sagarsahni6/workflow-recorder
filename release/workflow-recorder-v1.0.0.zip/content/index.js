"use strict";(()=>{var H={id:.99,name:.9,aria:.95,role:.88,testId:.97,dataAttr:.85,css:.7,xpath:.75,text:.6},G=[/^css-[a-z0-9]{4,}$/i,/^jss-?\d+$/i,/^[a-f0-9]{8}-[a-f0-9]{4}-/i,/^\d{10,}$/,/^[a-z0-9]{20,}$/i,/^__/,/^ng-/,/^ember\d+/];function u(){return`step_${Z()}`}function Z(){let n=Date.now().toString(36),t=Math.random().toString(36).substring(2,8);return`${n}_${t}`}function d(){return new Date().toISOString()}function m(n){let t=n.replace(/^[#.[\]]/,"").trim();return G.some(e=>e.test(n)||e.test(t))}function k(n,t=40){return n.length<=t?n:n.substring(0,t-1)+"\u2026"}function X(n){return n.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").substring(0,80)}function b(n){switch(n.type){case"navigate":return`Navigate to ${k(n.url,60)}`;case"click":{let t=v(n.target);return`${n.clickType==="double"?"Double-click":n.clickType==="right"?"Right-click":"Click"} "${t}"`}case"input":{let t=v(n.target);return n.sensitive?`Enter sensitive value in "${t}"`:`Enter "${k(n.value,30)}" in "${t}"`}case"select":{let t=v(n.target);return`Select "${n.label}" in "${t}"`}case"checkbox":{let t=v(n.target);return n.checked?`Check "${t}"`:`Uncheck "${t}"`}case"radio":{let t=v(n.target);return`Select radio "${n.value}" in "${t}"`}case"scroll":return`Scroll to position (${n.position.x}, ${n.position.y})`;case"hover":return`Hover over "${v(n.target)}"`;case"keyPress":return`Press ${q(n.modifiers)}${n.key}`;case"upload":return`Upload file to "${v(n.target)}"`;case"download":return`Download "${n.filename}"`;case"waitForElement":case"waitForVisible":case"waitForEnabled":case"waitForText":case"waitForURL":case"waitForDownload":case"waitForNavigation":return`Wait: ${n.type.replace("waitFor","")}`;case"newTab":return`Open new tab${n.url?`: ${k(n.url,50)}`:""}`;case"switchTab":return`Switch to tab ${n.tabId}`;case"closeTab":return`Close tab ${n.tabId}`;case"assert":return`Assert: ${n.assertion.operator} "${k(n.assertion.expected,30)}"`;case"condition":return`If: ${n.condition.operator} "${k(n.condition.value,30)}"`;case"loop":return`Loop over ${n.source}`;case"screenshot":return n.fullPage?"Take full page screenshot":"Take screenshot";default:return"Unknown action"}}function v(n){return n.ariaLabel||n.text||n.name||n.placeholder||n.id||n.tagName.toLowerCase()}function q(n){if(!n)return"";let t=[];return n.ctrl&&t.push("Ctrl+"),n.alt&&t.push("Alt+"),n.shift&&t.push("Shift+"),n.meta&&t.push("Meta+"),t.join("")}function Q(n){let t=Math.floor(n/1e3),e=Math.floor(t/3600),i=Math.floor(t%3600/60),r=t%60,s=a=>a.toString().padStart(2,"0");return`${s(e)}:${s(i)}:${s(r)}`}var A=Q;var R=class{static SENSITIVE_FIELD_NAMES=/password|passwd|pwd|secret|token|apikey|api_key|auth|bearer|cvv|cvc|ssn|social_security|credit_card|card_number|cardnum|aadhaar|pan_card|otp|pin|passcode/i;static SENSITIVE_INPUT_TYPES=new Set(["password"]);static CREDIT_CARD_REGEX=/\b(?:\d[ -]*?){13,19}\b/;static JWT_OR_AUTH_TOKEN_REGEX=/\b(?:Bearer\s+)?[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+\.?[A-Za-z0-9-_.+/=]*\b/;static PAN_CARD_REGEX=/\b[A-Z]{5}[0-9]{4}[A-Z]{1}\b/;static AADHAAR_REGEX=/\b\d{4}\s?\d{4}\s?\d{4}\b/;static isSensitiveField(t){return t.type&&this.SENSITIVE_INPUT_TYPES.has(t.type.toLowerCase())||t.autocomplete&&/current-password|new-password|cc-number|cc-csc|one-time-code/i.test(t.autocomplete)?!0:[t.name,t.id,t.ariaLabel,t.placeholder].filter(Boolean).some(i=>this.SENSITIVE_FIELD_NAMES.test(i))}static containsSensitiveData(t){if(!t||typeof t!="string")return!1;let e=t.trim();return!!(this.CREDIT_CARD_REGEX.test(e)&&e.replace(/\D/g,"").length>=13||this.PAN_CARD_REGEX.test(e)||this.AADHAAR_REGEX.test(e)&&e.replace(/\D/g,"").length===12||this.JWT_OR_AUTH_TOKEN_REGEX.test(e)&&e.length>30&&e.includes("."))}static maskValue(t="password"){return`{{${t.toLowerCase().replace(/[^a-z0-9_]/g,"_")}}}`}static sanitizeUrl(t){try{let e=new URL(t),i=["token","access_token","api_key","apikey","auth","sessionId","session_id","password","secret","signature"],r=!1;for(let s of i)e.searchParams.has(s)&&(e.searchParams.set(s,"[REDACTED]"),r=!0);return r?e.toString():t}catch{return t}}static sanitizeWorkflow(t){let e=JSON.parse(JSON.stringify(t));return e.steps=e.steps.map(i=>i.type==="navigate"?{...i,url:this.sanitizeUrl(i.url)}:i.type==="input"&&(i.sensitive||this.isSensitiveField({name:i.target.name,id:i.target.id,placeholder:i.target.placeholder,ariaLabel:i.target.ariaLabel})||this.containsSensitiveData(i.value))&&!i.value.startsWith("{{")&&!i.value.endsWith("}}")?{...i,value:this.maskValue(i.target.name||"sensitive_input"),sensitive:!0}:i),e}};var p=class{static MAX_TEXT_LENGTH=120;static inspect(t){let e=t.tagName.toUpperCase(),i=t.id?t.id.trim():void 0,r=t.getAttribute("name")?.trim()||void 0,s=t.getAttribute("type")?.toLowerCase()||void 0,a=t.getAttribute("role")?.trim()||void 0,o=t.getAttribute("title")?.trim()||void 0,l=t.getAttribute("placeholder")?.trim()||void 0,c=t.getAttribute("href")?.trim()||void 0,h=this.findAssociatedLabel(t),E=t.getAttribute("aria-label")?.trim()||h||void 0,y=this.extractStableClasses(t),f=this.extractText(t),{value:O,checked:B}=this.extractFormState(t),U=this.detectSensitive(t,{id:i,name:r,placeholder:l,ariaLabel:E,type:s}),W=this.getElementCenter(t),z=this.getFrameContext(t);return{tagName:e,id:i,name:r,type:s,text:f,ariaLabel:E,role:a,title:o,placeholder:l,labelText:h,classes:y,value:O,checked:B,href:c,isSensitive:U,position:W,frame:z}}static findAssociatedLabel(t){try{let e=t.ownerDocument,i=t.getAttribute("aria-labelledby");if(i){let s=e.getElementById(i);if(s){let a=this.extractText(s);if(a)return a}}if(t.id){let s=e.querySelector(`label[for="${CSS.escape(t.id)}"]`);if(s){let a=this.extractText(s);if(a)return a}}let r=t.closest("label");if(r){let s=this.extractText(r);if(s)return s}}catch{}}static findInteractiveAncestor(t){let e=t,i=0,r=6;for(;e&&e!==document.body&&i<r;){let s=e.tagName.toUpperCase();if(s==="BUTTON"||s==="A"||s==="INPUT"||s==="SELECT"||s==="TEXTAREA"||e.getAttribute("role")==="button"||e.getAttribute("role")==="link"||e.getAttribute("role")==="menuitem"||e.getAttribute("role")==="tab"||e.getAttribute("contenteditable")==="true"||e.getAttribute("data-action")!=null||tt(e))return e;e=e.parentElement,i++}return t}static extractStableClasses(t){let e=t.getAttribute("class");return e?e.split(/\s+/).map(i=>i.trim()).filter(i=>!i||i.length<2||i.length>50?!1:!m(`.${i}`)):[]}static extractText(t){let r=(t.innerText||t.textContent||"").replace(/\s+/g," ").trim();if(r)return r.length>this.MAX_TEXT_LENGTH?r.substring(0,this.MAX_TEXT_LENGTH)+"...":r}static extractFormState(t){let e=t.tagName.toUpperCase();if(e==="INPUT"){let i=t,r=(i.type||"text").toLowerCase();return r==="checkbox"||r==="radio"?{checked:i.checked,value:i.value}:{value:i.value}}return e==="TEXTAREA"?{value:t.value}:e==="SELECT"?{value:t.value}:{}}static detectSensitive(t,e){let i=t.getAttribute("autocomplete")?.toLowerCase();return R.isSensitiveField({id:e.id,name:e.name,placeholder:e.placeholder,ariaLabel:e.ariaLabel,type:e.type,autocomplete:i})}static getElementCenter(t){try{let e=t.getBoundingClientRect();return{x:Math.round(e.left+e.width/2),y:Math.round(e.top+e.height/2)}}catch{return{x:0,y:0}}}static getFrameContext(t){try{let e=t.ownerDocument.defaultView;if(e&&e!==e.top){let i=[];try{let r=e.parent.document,s=Array.from(r.querySelectorAll("iframe"));for(let a of s)if(a.contentWindow===e){a.id&&!m(`#${a.id}`)?i.push({type:"id",value:`#${CSS.escape(a.id)}`,score:.99}):a.getAttribute("name")?i.push({type:"name",value:`iframe[name="${a.getAttribute("name")}"]`,score:.9}):a.getAttribute("src")&&i.push({type:"css",value:`iframe[src="${a.getAttribute("src")}"]`,score:.7});break}}catch{}return{type:"iframe",depth:1,selectors:i}}}catch{}return{type:"main",depth:0,selectors:[]}}static toElementTarget(t,e){return{tagName:t.tagName,id:t.id,name:t.name,type:t.type,text:t.text,ariaLabel:t.ariaLabel,role:t.role,title:t.title,placeholder:t.placeholder,classes:t.classes,selectors:e,frame:t.frame}}};function tt(n){try{let t=n.style;if(t&&t.cursor==="pointer")return!0;if(typeof window<"u"&&window.getComputedStyle)return window.getComputedStyle(n).cursor==="pointer"}catch{}return!1}var I=class{static VOLATILE_TEXT_PATTERNS=[/^\$?\d+(\.\d{1,2})?$/,/^[₹€£¥]\s?\d+/,/\b\d{4}[-/.]\d{2}[-/.]\d{2}\b/,/\b\d{1,2}:\d{2}(:\d{2})?\b/,/#\d{4,}/,/\b(item|result)s?\s+\d+\b/i];static calculateScore(t){let{type:e,value:i,matchCount:r}=t;if(r<=0)return 0;let s=H[e]??.5;m(i)&&(s-=.5),r>1&&(s*=1/r);let a=t.domDepth??this.estimateDepth(i,e);return a>3&&(s-=(a-3)*.05),(e==="text"||i.includes("normalize-space()")||i.includes(":has-text"))&&this.isVolatileText(t.text||i)&&(s-=.25),(e==="aria"||e==="role")&&(i.includes("aria-label")||i.includes("[name="))&&(s+=.02),Math.round(Math.min(.99,Math.max(.01,s))*100)/100}static estimateDepth(t,e){if(e==="id"||e==="testId")return 1;if(e==="css"){let i=t.split(/\s*>\s*|\s+/).filter(Boolean);return Math.max(1,i.length)}if(e==="xpath"){let i=t.split("/").filter(Boolean);return Math.max(1,i.length)}return 1}static isVolatileText(t){let e=t.trim();return this.VOLATILE_TEXT_PATTERNS.some(i=>i.test(e))}static rankCandidates(t){let e=[...t].sort((r,s)=>s.score-r.score),i=new Set;return e.filter(r=>i.has(r.value)?!1:(i.add(r.value),!0))}};var x=class{static validate(t,e,i,r=document){let s=typeof performance<"u"?performance.now():Date.now();try{return e==="xpath"||e==="text"?this.validateXPath(t,i,r,s):this.validateCss(t,i,r,s)}catch(a){let o=(typeof performance<"u"?performance.now():Date.now())-s,l=a instanceof Error?a.message:"Invalid selector";return{isValid:!1,matches:0,isTarget:!1,matchedElement:null,executionTimeMs:o,error:l}}}static validateCss(t,e,i,r){let s=i.querySelectorAll(t),a=(typeof performance<"u"?performance.now():Date.now())-r,o=s.length,l=s[0]||null,c=e?l===e:o>0;return{isValid:o>0,matches:o,isTarget:c,matchedElement:l,executionTimeMs:a}}static validateXPath(t,e,i,r){let s=i.evaluate(t,i,null,XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,null),a=(typeof performance<"u"?performance.now():Date.now())-r,o=s.snapshotLength,l=o>0?s.snapshotItem(0):null,c=e?l===e:o>0;return{isValid:o>0,matches:o,isTarget:c,matchedElement:l,executionTimeMs:a}}static validateAndScoreCandidates(t,e,i=document){let r=[];for(let s of t){let a=this.validate(s.value,s.type,e,i);if(!a.isValid||!a.isTarget)continue;let o=I.calculateScore({type:s.type,value:s.value,matchCount:a.matches});r.push({type:s.type,value:s.value,score:o})}return I.rankCandidates(r)}};var L=class{static TIER_MAP={id:1,testId:1,aria:2,role:2,css:3,xpath:4,name:5,text:5,dataAttr:5};static sortByFallbackHierarchy(t){return[...t].sort((e,i)=>{let r=this.TIER_MAP[e.type]??99,s=this.TIER_MAP[i.type]??99;return r!==s?r-s:i.score-e.score})}static resolve(t,e=document){let i=this.sortByFallbackHierarchy(t.selectors||[]),r=null;for(let s of i){let a=x.validate(s.value,s.type,void 0,e);if(a.isValid&&a.matchedElement){if(a.matches===1){let o=this.TIER_MAP[s.type]??5;return{element:a.matchedElement,usedSelector:s,tier:o,confidence:s.score,strategy:o===1?"exact":"fallback"}}r||(r={candidate:s,element:a.matchedElement,matches:a.matches})}}if(r){let s=this.TIER_MAP[r.candidate.type]??5;return{element:r.element,usedSelector:r.candidate,tier:s,confidence:Math.round(r.candidate.score/r.matches*100)/100,strategy:"ambiguous"}}return{element:null,usedSelector:null,tier:-1,confidence:0,strategy:"failed"}}};var C=class{static generate(t,e=document){return this.generateSelectors(t,e)}static generateSelectors(t,e=document){let i=[],r=this.generateIdSelector(t);r&&i.push(r);let s=this.generateTestIdSelector(t);s&&i.push(s);let a=this.generateAriaSelector(t);a&&i.push(a);let o=this.generateRoleSelector(t);o&&i.push(o);let l=this.generateNameSelector(t);l&&i.push(l);let c=this.generateSemanticAttrSelector(t);c&&i.push(c);let h=this.generateTextSelector(t);h&&i.push(h);let E=this.generateCssSelector(t);E&&i.push(E);let y=this.generateXPathSelector(t);y&&i.push(y);let f=x.validateAndScoreCandidates(i,t,e);return L.sortByFallbackHierarchy(f)}static validateAndScore(t,e,i=document){return x.validateAndScoreCandidates([t],e,i)[0]||null}static generateIdSelector(t){let e=t.id?t.id.trim():"";return!e||m(`#${e}`)?null:{type:"id",value:`#${CSS.escape(e)}`,score:.99}}static generateTestIdSelector(t){let e=["data-testid","data-test-id","data-qa","data-cy","data-test"];for(let i of e){let r=t.getAttribute(i)?.trim();if(r)return{type:"testId",value:`[${i}="${g(r)}"]`,score:.97}}return null}static generateAriaSelector(t){let e=t.getAttribute("aria-label")?.trim()||p.findAssociatedLabel(t);return e&&e.length<=80?{type:"aria",value:`${t.tagName.toLowerCase()}[aria-label="${g(e)}"]`,score:.92}:null}static generateRoleSelector(t){let e=t.getAttribute("role")?.trim();if(e){let i=t.getAttribute("aria-label")?.trim()||p.findAssociatedLabel(t);return{type:"role",value:i?`[role="${g(e)}"][aria-label="${g(i)}"]`:`[role="${g(e)}"]`,score:.88}}return null}static generateNameSelector(t){let e=t.getAttribute("name")?.trim();return e?{type:"name",value:`${t.tagName.toLowerCase()}[name="${g(e)}"]`,score:.85}:null}static generateSemanticAttrSelector(t){let e=t.getAttribute("placeholder")?.trim(),i=t.tagName.toLowerCase();if(e&&e.length<=50)return{type:"css",value:`${i}[placeholder="${g(e)}"]`,score:.82};let r=t.getAttribute("title")?.trim();return r&&r.length<=50?{type:"css",value:`${i}[title="${g(r)}"]`,score:.8}:null}static generateTextSelector(t){let e=t.tagName.toLowerCase();if(e!=="button"&&e!=="a"&&t.getAttribute("role")!=="button")return null;let i=(t.textContent||"").trim().replace(/\s+/g," ");return!i||i.length>50?null:{type:"text",value:`//${e}[normalize-space()="${g(i)}"]`,score:.75}}static generateCssSelector(t){let e=t.tagName.toLowerCase(),i=p.extractStableClasses(t);if(i.length>0)return{type:"css",value:`${e}.${i.map(o=>CSS.escape(o)).join(".")}`,score:.72};let r=t.getAttribute("type");if(r)return{type:"css",value:`${e}[type="${g(r)}"]`,score:.7};let s=this.buildCssPath(t);return s?{type:"css",value:s,score:.65}:null}static generateXPathSelector(t){let e=t.tagName.toLowerCase();if(t.id&&!m(`#${t.id}`))return{type:"xpath",value:`//${e}[@id='${t.id.trim()}']`,score:.75};let i=t.getAttribute("name");if(i)return{type:"xpath",value:`//${e}[@name='${i.trim()}']`,score:.72};let r=this.buildXPath(t);return r?{type:"xpath",value:r,score:.65}:null}static buildCssPath(t){let e=[],i=t,r=0;for(;i&&i!==document.body&&r<4;){let s=i.tagName.toLowerCase();if(i.id&&!m(`#${i.id}`)){e.unshift(`#${CSS.escape(i.id)}`);break}let a=i.parentElement;if(a){let o=Array.from(a.children).filter(l=>l.tagName===i.tagName);if(o.length>1){let l=o.indexOf(i)+1;s+=`:nth-of-type(${l})`}}e.unshift(s),i=a,r++}return e.join(" > ")}static buildXPath(t){let e=[],i=t,r=0;for(;i&&i.nodeType===Node.ELEMENT_NODE&&r<5;){if(i.id&&!m(`#${i.id}`)){e.unshift(`//${i.tagName.toLowerCase()}[@id='${i.id}']`);break}let s=1,a=i.previousElementSibling;for(;a;)a.tagName===i.tagName&&s++,a=a.previousElementSibling;let o=i.tagName.toLowerCase();e.unshift(s>1?`${o}[${s}]`:o),i=i.parentElement,r++}return e.length>0?e[0].startsWith("//")?e.join("/"):`//${e.join("/")}`:`//${t.tagName.toLowerCase()}`}};function g(n){return n.replace(/"/g,'\\"')}var M=class n{pendingInput=null;pendingScroll=null;onStepCallback;static INPUT_DEBOUNCE_MS=1200;static SCROLL_DEBOUNCE_MS=350;constructor(t){this.onStepCallback=t}handleStep(t,e){if(t.type==="input"){this.handleInputStep(t,e);return}if(t.type==="scroll"){this.handleScrollStep(t);return}this.flush(),this.emit(t)}handleInputStep(t,e){if(this.flushScroll(),this.pendingInput&&e&&this.pendingInput.element===e){this.pendingInput.timer&&clearTimeout(this.pendingInput.timer),this.pendingInput.value=t.value,this.pendingInput.sensitive=t.sensitive||this.pendingInput.sensitive,this.pendingInput.target=t.target,this.pendingInput.timer=setTimeout(()=>{this.flushInput()},n.INPUT_DEBOUNCE_MS);return}this.flushInput();let i=setTimeout(()=>{this.flushInput()},n.INPUT_DEBOUNCE_MS);this.pendingInput={element:e||null,target:t.target,value:t.value,sensitive:t.sensitive,timestamp:t.timestamp||d(),timer:i}}handleScrollStep(t){this.pendingScroll?.timer&&clearTimeout(this.pendingScroll.timer);let e=setTimeout(()=>{this.flushScroll()},n.SCROLL_DEBOUNCE_MS);this.pendingScroll={position:t.position,target:t.target,timestamp:t.timestamp||d(),timer:e}}flush(){this.flushInput(),this.flushScroll()}flushInput(){if(!this.pendingInput)return;this.pendingInput.timer&&clearTimeout(this.pendingInput.timer);let{target:t,value:e,sensitive:i,timestamp:r}=this.pendingInput;this.pendingInput=null;let s=i?"{{password}}":e,a={id:u(),type:"input",target:t,value:s,sensitive:i,description:b({type:"input",target:t,value:s,sensitive:i}),timestamp:r};this.emit(a)}flushScroll(){if(!this.pendingScroll)return;this.pendingScroll.timer&&clearTimeout(this.pendingScroll.timer);let{position:t,target:e,timestamp:i}=this.pendingScroll;this.pendingScroll=null;let r={id:u(),type:"scroll",position:t,target:e,description:`Scroll to (${t.x}, ${t.y})`,timestamp:i};this.emit(r)}hasPendingInput(){return this.pendingInput!==null}hasPendingScroll(){return this.pendingScroll!==null}emit(t){try{this.onStepCallback(t)}catch(e){console.error("[EventNormalizer] Error emitting step:",e)}}destroy(){this.pendingInput?.timer&&(clearTimeout(this.pendingInput.timer),this.pendingInput=null),this.pendingScroll?.timer&&(clearTimeout(this.pendingScroll.timer),this.pendingScroll=null)}};var N=class{static handleFileInput(t){let e=p.inspect(t),i=C.generate(t),r={tagName:t.tagName.toUpperCase(),id:e.id,name:e.name,type:"file",classes:e.classes,selectors:i},s=e.name||e.id||e.ariaLabel||"document",a=X(s).replace(/-/g,"_"),o=/^[a-zA-Z_]/.test(a)?a:`file_${a}`;return{id:u(),type:"upload",target:r,file:`{{${o}}}`,timestamp:d(),description:`Upload document to ${r.name||r.id||"file input"}`}}};var _=class n{isCapturing=!1;isPaused=!1;normalizer;boundListeners=new Map;lastClickTime=0;lastClickTarget=null;static CONTROLLER_TAG="WORKFLOW-RECORDER-CONTROLLER";static IGNORE_ATTR="data-workflow-recorder-ignore";constructor(t){this.normalizer=new M(t.onStep)}start(){this.isCapturing||(this.isCapturing=!0,this.isPaused=!1,this.attachListeners())}stop(){this.isCapturing&&(this.normalizer.flush(),this.detachListeners(),this.normalizer.destroy(),this.isCapturing=!1,this.isPaused=!1)}pause(){this.isCapturing&&(this.normalizer.flush(),this.isPaused=!0)}resume(){this.isCapturing&&(this.isPaused=!1)}shouldIgnoreEvent(t){let e=t.composedPath?t.composedPath():[];for(let r of e)if(r instanceof HTMLElement&&(r.tagName.toUpperCase()===n.CONTROLLER_TAG||r.hasAttribute(n.IGNORE_ATTR)||r.id==="workflow-recorder-floating-controller"))return!0;let i=t.target;return!!(i&&i.closest&&(i.closest(n.CONTROLLER_TAG.toLowerCase())||i.closest(`[${n.IGNORE_ATTR}]`)))}handleClick=t=>{if(!this.isCapturing||this.isPaused||this.shouldIgnoreEvent(t)||t.button===2)return;let e=t.target;if(!e)return;this.normalizer.flush();let i=Date.now(),r=this.lastClickTarget===e&&i-this.lastClickTime<300;this.lastClickTime=i,this.lastClickTarget=e;let s=r?"double":"left",a=p.findInteractiveAncestor(e),o=this.buildElementTarget(a),l={id:u(),type:"click",target:o,clickType:s,position:{x:Math.round(t.clientX),y:Math.round(t.clientY)},timestamp:d(),description:b({type:"click",target:o,clickType:s})};this.normalizer.handleStep(l)};handleContextMenu=t=>{if(!this.isCapturing||this.isPaused||this.shouldIgnoreEvent(t))return;let e=t.target;if(!e)return;this.normalizer.flush();let i=p.findInteractiveAncestor(e),r=this.buildElementTarget(i),s={id:u(),type:"click",target:r,clickType:"right",position:{x:Math.round(t.clientX),y:Math.round(t.clientY)},timestamp:d(),description:b({type:"click",target:r,clickType:"right"})};this.normalizer.handleStep(s)};handleInput=t=>{if(!this.isCapturing||this.isPaused||this.shouldIgnoreEvent(t))return;let e=t.target;if(!e)return;let i=e.tagName.toUpperCase();if(i==="INPUT"){let a=(e.getAttribute("type")||"text").toLowerCase();if(a==="checkbox"||a==="radio"||a==="file")return}if(i==="SELECT")return;let r=p.inspect(e),s=this.buildElementTarget(e,r);this.normalizer.handleStep({id:u(),type:"input",target:s,value:r.value||"",sensitive:r.isSensitive,timestamp:d(),description:""},e)};handleChange=t=>{if(!this.isCapturing||this.isPaused||this.shouldIgnoreEvent(t))return;let e=t.target;if(!e)return;let i=e.tagName.toUpperCase();if(i==="SELECT"){this.normalizer.flush();let r=e,s=this.buildElementTarget(r),a=r.options[r.selectedIndex],o=r.value,l=a?a.text.trim():o,c={id:u(),type:"select",target:s,value:o,label:l,timestamp:d(),description:b({type:"select",target:s,value:o,label:l})};this.normalizer.handleStep(c);return}if(i==="INPUT"){let r=e,s=(r.type||"text").toLowerCase();if(s==="checkbox"){this.normalizer.flush();let a=this.buildElementTarget(r),o=r.checked,l={id:u(),type:"checkbox",target:a,checked:o,timestamp:d(),description:b({type:"checkbox",target:a,checked:o})};this.normalizer.handleStep(l);return}if(s==="radio"){this.normalizer.flush();let a=this.buildElementTarget(r),o=r.value,l={id:u(),type:"radio",target:a,value:o,timestamp:d(),description:b({type:"radio",target:a,value:o})};this.normalizer.handleStep(l);return}if(s==="file"){this.normalizer.flush();let a=N.handleFileInput(r);this.normalizer.handleStep(a);return}}};handleKeyDown=t=>{if(!this.isCapturing||this.isPaused||this.shouldIgnoreEvent(t))return;let e=["Enter","Escape","Tab","Backspace","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"],i=t.ctrlKey||t.metaKey||t.altKey;if(!e.includes(t.key)&&!i)return;(t.key==="Enter"||t.key==="Tab")&&this.normalizer.flush();let r=t.target,s=r?this.buildElementTarget(r):void 0,a={};t.ctrlKey&&(a.ctrl=!0),t.altKey&&(a.alt=!0),t.shiftKey&&(a.shift=!0),t.metaKey&&(a.meta=!0);let o={id:u(),type:"keyPress",key:t.key,modifiers:Object.keys(a).length>0?a:void 0,target:s,timestamp:d(),description:b({type:"keyPress",key:t.key,modifiers:a})};this.normalizer.handleStep(o)};handleScroll=()=>{if(!this.isCapturing||this.isPaused)return;let t=Math.round(window.scrollX||window.pageXOffset||0),e=Math.round(window.scrollY||window.pageYOffset||0),i={id:u(),type:"scroll",position:{x:t,y:e},timestamp:d(),description:`Scroll to (${t}, ${e})`};this.normalizer.handleStep(i)};handleFocusOut=t=>{!this.isCapturing||this.isPaused||this.shouldIgnoreEvent(t)||this.normalizer.hasPendingInput()&&this.normalizer.flushInput()};buildElementTarget(t,e){let i=e||p.inspect(t),r=C.generateSelectors(t);return p.toElementTarget(i,r)}attachListeners(){let t=document,e=window,i=[[t,"click",this.handleClick,{capture:!0,passive:!0}],[t,"contextmenu",this.handleContextMenu,{capture:!0,passive:!0}],[t,"input",this.handleInput,{capture:!0,passive:!0}],[t,"change",this.handleChange,{capture:!0,passive:!0}],[t,"keydown",this.handleKeyDown,{capture:!0,passive:!0}],[t,"focusout",this.handleFocusOut,{capture:!0,passive:!0}],[e,"scroll",this.handleScroll,{capture:!0,passive:!0}]];for(let[r,s,a,o]of i)r.addEventListener(s,a,o),this.boundListeners.set(`${s}_${r===t?"doc":"win"}`,{target:r,eventType:s,handler:a,options:o})}detachListeners(){for(let[,{target:t,eventType:e,handler:i,options:r}]of this.boundListeners)t.removeEventListener(e,i,r);this.boundListeners.clear()}};var V="workflow_recorder_floating_pos",K="workflow_recorder_floating_collapsed",D=class{host=null;shadow=null;timerInterval=null;startTime=0;elapsedMs=0;actionCount=0;isPaused=!1;isCollapsed=!1;callbacks;isDragging=!1;dragStartX=0;dragStartY=0;initialLeft=24;initialTop=24;constructor(t){this.callbacks=t;try{this.isCollapsed=sessionStorage.getItem(K)==="true"}catch{}}mount(t){if(this.host)return;this.isPaused=!!t?.isPaused,this.actionCount=t?.actionCount||0,this.startTime=t?.startTime||Date.now(),this.elapsedMs=this.isPaused?0:Math.max(0,Date.now()-this.startTime),this.host=document.createElement("workflow-recorder-controller"),this.host.id="workflow-recorder-floating-controller",this.host.setAttribute("data-workflow-recorder-ignore","true");let e=null;try{let i=sessionStorage.getItem(V);i&&(e=JSON.parse(i))}catch{}if(Object.assign(this.host.style,{position:"fixed",zIndex:"2147483647",fontFamily:'-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',userSelect:"none",cursor:"default",transition:"opacity 0.2s ease, transform 0.2s ease"}),e&&typeof e.left=="number"&&typeof e.top=="number"){let i=Math.max(10,window.innerWidth-380),r=Math.max(10,window.innerHeight-60),s=Math.min(Math.max(10,e.left),i),a=Math.min(Math.max(10,e.top),r);this.host.style.left=`${s}px`,this.host.style.top=`${a}px`,this.host.style.bottom="auto",this.host.style.right="auto"}else this.host.style.bottom="24px",this.host.style.right="24px";this.shadow=this.host.attachShadow({mode:"open"}),this.render(),this.setupEvents(),document.body.appendChild(this.host),this.isPaused||this.startTimer()}updateState(t){t.isPaused!==void 0&&t.isPaused!==this.isPaused&&(this.isPaused=t.isPaused,this.isPaused?this.stopTimer():(this.startTime=Date.now()-(this.elapsedMs||0),this.startTimer())),t.actionCount!==void 0&&(this.actionCount=t.actionCount),t.elapsedMs!==void 0&&(this.elapsedMs=t.elapsedMs),this.updateDom()}unmount(){this.stopTimer(),this.host&&this.host.parentNode&&this.host.parentNode.removeChild(this.host),this.host=null,this.shadow=null}render(){if(!this.shadow)return;let t=`
      :host {
        all: initial;
        display: block;
      }

      *, *::before, *::after {
        box-sizing: border-box;
      }

      .floating-toolbar {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        background: rgba(255, 255, 255, 0.96);
        color: #0f172a;
        padding: 6px 10px;
        border-radius: 9999px;
        border: 1px solid rgba(203, 213, 225, 0.9);
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.12), 0 8px 10px -6px rgba(0, 0, 0, 0.08), 0 0 0 1px rgba(255, 255, 255, 0.8) inset;
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        font-size: 13px;
        user-select: none;
        transition: box-shadow 0.2s ease, border-color 0.2s ease, padding 0.2s ease;
      }

      .floating-toolbar:hover {
        box-shadow: 0 14px 30px -5px rgba(0, 0, 0, 0.16), 0 10px 12px -6px rgba(0, 0, 0, 0.1);
        border-color: #94a3b8;
      }

      /* Drag Grip Handle */
      .drag-handle {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 18px;
        height: 28px;
        cursor: grab;
        color: #94a3b8;
        border-radius: 4px;
        transition: color 0.15s ease, background 0.15s ease;
      }

      .drag-handle:hover {
        color: #475569;
        background: #f1f5f9;
      }

      .drag-handle:active {
        cursor: grabbing;
      }

      /* Status Pill (Indicator + Clock) */
      .status-pill {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 4px 10px;
        border-radius: 9999px;
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        font-weight: 600;
        font-size: 12px;
      }

      .pulse-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background-color: #ef4444;
        box-shadow: 0 0 8px #ef4444;
        animation: recPulse 1.5s infinite ease-in-out;
      }

      .pulse-dot.paused {
        background-color: #f59e0b;
        box-shadow: 0 0 6px #f59e0b;
        animation: none;
      }

      @keyframes recPulse {
        0%, 100% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.25); opacity: 0.7; }
      }

      .status-label {
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.5px;
        color: #ef4444;
        text-transform: uppercase;
      }

      .status-label.paused {
        color: #d97706;
      }

      .timer-display {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 12px;
        color: #334155;
        font-weight: 600;
      }

      /* Steps badge */
      .steps-badge {
        display: inline-flex;
        align-items: center;
        padding: 3px 8px;
        border-radius: 9999px;
        background: #f0f9ff;
        color: #0284c7;
        border: 1px solid #bae6fd;
        font-size: 11px;
        font-weight: 600;
        white-space: nowrap;
      }

      /* Divider */
      .divider {
        width: 1px;
        height: 20px;
        background: #e2e8f0;
        margin: 0 2px;
      }

      /* Button Base */
      button {
        border: none;
        outline: none;
        padding: 5px 12px;
        border-radius: 9999px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
        transition: all 0.15s ease;
        line-height: 1.2;
      }

      button:active {
        transform: scale(0.96);
      }

      /* Pause / Resume Button */
      .btn-pause {
        background: #f1f5f9;
        border: 1px solid #cbd5e1;
        color: #1e293b;
      }

      .btn-pause:hover {
        background: #e2e8f0;
        border-color: #94a3b8;
      }

      .btn-pause.is-paused {
        background: #fef3c7;
        border-color: #fcd34d;
        color: #b45309;
        box-shadow: 0 0 8px rgba(245, 158, 11, 0.25);
      }

      .btn-pause.is-paused:hover {
        background: #fde68a;
      }

      /* Stop Button */
      .btn-stop {
        background: #dc2626;
        border: 1px solid #b91c1c;
        color: #ffffff;
        box-shadow: 0 2px 4px rgba(220, 38, 38, 0.25);
      }

      .btn-stop:hover {
        background: #b91c1c;
        border-color: #991b1b;
        box-shadow: 0 4px 8px rgba(220, 38, 38, 0.35);
      }

      /* Icon Buttons (Editor, Collapse) */
      .btn-icon {
        background: transparent;
        border: 1px solid transparent;
        color: #64748b;
        padding: 6px;
        border-radius: 50%;
        width: 28px;
        height: 28px;
      }

      .btn-icon:hover {
        background: #f1f5f9;
        border-color: #e2e8f0;
        color: #0f172a;
      }

      /* Collapsed Mode */
      .floating-toolbar.collapsed .steps-badge,
      .floating-toolbar.collapsed .status-label,
      .floating-toolbar.collapsed .btn-label {
        display: none;
      }

      .floating-toolbar.collapsed button {
        padding: 6px;
        width: 28px;
        height: 28px;
        border-radius: 50%;
      }
    `,e=this.isPaused,i=this.isCollapsed?"collapsed":"";this.shadow.innerHTML=`
      <style>${t}</style>
      <div class="floating-toolbar ${i}" id="toolbar">
        <!-- Drag Handle -->
        <div class="drag-handle" id="dragHandle" title="Drag to reposition anywhere on screen">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
            <circle cx="9" cy="5" r="2"/><circle cx="15" cy="5" r="2"/>
            <circle cx="9" cy="12" r="2"/><circle cx="15" cy="12" r="2"/>
            <circle cx="9" cy="19" r="2"/><circle cx="15" cy="19" r="2"/>
          </svg>
        </div>

        <!-- Status & Live Timer -->
        <div class="status-pill" id="statusPill" title="${e?"Recording Paused":"Recording in Progress"}">
          <span class="pulse-dot ${e?"paused":""}" id="pulseDot"></span>
          <span class="status-label ${e?"paused":""}" id="statusLabel">${e?"PAUSED":"REC"}</span>
          <span class="timer-display" id="timerText">${A(this.elapsedMs)}</span>
        </div>

        <!-- Actions Counter -->
        <span class="steps-badge" id="actionCount">${this.actionCount} steps</span>

        <div class="divider"></div>

        <!-- Pause / Resume Button -->
        <button class="btn-pause ${e?"is-paused":""}" id="btnPause" title="${e?"Resume Recording (Alt+P)":"Pause Recording (Alt+P)"}">
          <span id="pauseIcon">${e?this.getPlaySvg():this.getPauseSvg()}</span>
          <span class="btn-label" id="pauseLabel">${e?"Resume":"Pause"}</span>
        </button>

        <!-- Stop Button -->
        <button class="btn-stop" id="btnStop" title="Stop Recording & Save Workflow (Alt+S)">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" stroke="none">
            <rect x="4" y="4" width="16" height="16" rx="2"/>
          </svg>
          <span class="btn-label">Stop</span>
        </button>

        <!-- Open Editor Button -->
        <button class="btn-icon" id="btnEditor" title="Open Workflow Editor">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/>
          </svg>
        </button>

        <!-- Collapse / Expand Toggle Button -->
        <button class="btn-icon" id="btnCollapse" title="${this.isCollapsed?"Expand Toolbar":"Minimize Toolbar"}">
          <svg id="collapseIcon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            ${this.isCollapsed?'<polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/>':'<polyline points="4 14 10 14 10 20"/><polyline points="20 10 14 10 14 4"/><line x1="14" y1="10" x2="21" y2="3"/><line x1="3" y1="21" x2="10" y2="14"/>'}
          </svg>
        </button>
      </div>
    `}getPauseSvg(){return`<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" stroke="none">
      <rect x="6" y="4" width="4" height="16" rx="1"/>
      <rect x="14" y="4" width="4" height="16" rx="1"/>
    </svg>`}getPlaySvg(){return`<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" stroke="none">
      <polygon points="5 3 19 12 5 21 5 3"/>
    </svg>`}updateDom(){if(!this.shadow)return;let t=this.shadow.getElementById("pulseDot"),e=this.shadow.getElementById("statusLabel"),i=this.shadow.getElementById("timerText"),r=this.shadow.getElementById("actionCount"),s=this.shadow.getElementById("btnPause"),a=this.shadow.getElementById("pauseIcon"),o=this.shadow.getElementById("pauseLabel");t&&(t.className=`pulse-dot ${this.isPaused?"paused":""}`),e&&(e.className=`status-label ${this.isPaused?"paused":""}`,e.textContent=this.isPaused?"PAUSED":"REC"),i&&(i.textContent=A(this.elapsedMs)),r&&(r.textContent=`${this.actionCount} steps`),s&&(s.className=`btn-pause ${this.isPaused?"is-paused":""}`,s.title=this.isPaused?"Resume Recording (Alt+P)":"Pause Recording (Alt+P)"),a&&(a.innerHTML=this.isPaused?this.getPlaySvg():this.getPauseSvg()),o&&(o.textContent=this.isPaused?"Resume":"Pause")}setupEvents(){if(!this.shadow||!this.host)return;let t=c=>{c.stopPropagation()},e=["click","mousedown","mouseup","pointerdown","pointerup","keydown","keyup","dblclick","contextmenu"];for(let c of e)this.shadow.addEventListener(c,t);let i=this.shadow.getElementById("btnPause"),r=this.shadow.getElementById("btnStop"),s=this.shadow.getElementById("btnEditor"),a=this.shadow.getElementById("btnCollapse"),o=this.shadow.getElementById("toolbar");i?.addEventListener("click",c=>{c.stopPropagation(),this.isPaused?this.callbacks.onResume():this.callbacks.onPause()}),r?.addEventListener("click",c=>{c.stopPropagation(),this.callbacks.onStop()}),s?.addEventListener("click",c=>{c.stopPropagation(),this.callbacks.onOpenEditor()}),a?.addEventListener("click",c=>{c.stopPropagation(),this.isCollapsed=!this.isCollapsed;try{sessionStorage.setItem(K,String(this.isCollapsed))}catch{}o&&o.classList.toggle("collapsed",this.isCollapsed),a.title=this.isCollapsed?"Expand Toolbar":"Minimize Toolbar";let h=this.shadow?.getElementById("collapseIcon");h&&(h.innerHTML=this.isCollapsed?'<polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/>':'<polyline points="4 14 10 14 10 20"/><polyline points="20 10 14 10 14 4"/><line x1="14" y1="10" x2="21" y2="3"/><line x1="3" y1="21" x2="10" y2="14"/>')});let l=this.shadow.getElementById("dragHandle");l&&l.addEventListener("mousedown",c=>{if(c.button!==0)return;this.isDragging=!0,this.dragStartX=c.clientX,this.dragStartY=c.clientY;let h=this.host.getBoundingClientRect();this.initialLeft=h.left,this.initialTop=h.top,this.host.style.bottom="auto",this.host.style.right="auto",this.host.style.left=`${this.initialLeft}px`,this.host.style.top=`${this.initialTop}px`;let E=f=>{if(!this.isDragging||!this.host)return;let O=f.clientX-this.dragStartX,B=f.clientY-this.dragStartY,U=this.host.offsetWidth||340,W=this.host.offsetHeight||44,z=Math.max(10,Math.min(window.innerWidth-U-10,this.initialLeft+O)),J=Math.max(10,Math.min(window.innerHeight-W-10,this.initialTop+B));this.host.style.left=`${z}px`,this.host.style.top=`${J}px`},y=()=>{if(this.isDragging=!1,window.removeEventListener("mousemove",E),window.removeEventListener("mouseup",y),this.host){let f=this.host.getBoundingClientRect();try{sessionStorage.setItem(V,JSON.stringify({left:Math.round(f.left),top:Math.round(f.top)}))}catch{}}};window.addEventListener("mousemove",E),window.addEventListener("mouseup",y)})}startTimer(){this.timerInterval||(this.timerInterval=setInterval(()=>{if(!this.isPaused){this.elapsedMs=Date.now()-this.startTime;let t=this.shadow?.getElementById("timerText");t&&(t.textContent=A(this.elapsedMs))}},1e3))}stopTimer(){this.timerInterval&&(clearInterval(this.timerInterval),this.timerInterval=null)}};var T=!1,S=!1,$=0,Y=0,P=null,w=null;function et(){w=new D({onPause:()=>{chrome.runtime.sendMessage({type:"PAUSE_RECORDING"}).catch(()=>{})},onResume:()=>{chrome.runtime.sendMessage({type:"RESUME_RECORDING"}).catch(()=>{})},onStop:()=>{chrome.runtime.sendMessage({type:"STOP_RECORDING"}).catch(()=>{})},onOpenEditor:()=>{chrome.runtime.sendMessage({type:"OPEN_EDITOR"}).catch(()=>{})}}),P=new _({onStep:it}),chrome.runtime.sendMessage({type:"CONTENT_SCRIPT_READY"}).then(n=>{n&&n.type==="RECORDING_STATE"&&(n.state.status==="recording"?F(n.state.actionCount,n.state.startTime||Date.now()):n.state.status==="paused"&&(F(n.state.actionCount,n.state.startTime||Date.now()),j()))}).catch(()=>{})}function it(n){$++,w?.updateState({actionCount:$}),chrome.runtime.sendMessage({type:"EVENT_RECORDED",step:n}).catch(t=>{console.warn("[Workflow Recorder] Failed to send step to service worker:",t)})}function F(n=0,t=Date.now(),e=!1){T||(T=!0,S=e,$=n,Y=t,S||P?.start(),w?.mount({isPaused:S,actionCount:$,startTime:Y}))}function rt(){T&&(T=!1,S=!1,P?.stop(),w?.unmount())}function j(){!T||S||(S=!0,P?.pause(),w?.updateState({isPaused:!0}))}function st(){!T||!S||(S=!1,P?.resume(),w?.updateState({isPaused:!1}))}window.addEventListener("keydown",n=>{if(T){if(n.altKey&&(n.key==="p"||n.key==="P")){n.preventDefault(),n.stopPropagation(),S?chrome.runtime.sendMessage({type:"RESUME_RECORDING"}).catch(()=>{}):chrome.runtime.sendMessage({type:"PAUSE_RECORDING"}).catch(()=>{});return}if(n.altKey&&(n.key==="s"||n.key==="S")){n.preventDefault(),n.stopPropagation(),chrome.runtime.sendMessage({type:"STOP_RECORDING"}).catch(()=>{});return}}},!0);chrome.runtime.onMessage.addListener((n,t,e)=>{switch(n.type){case"START_CAPTURING":{let i=n;F(i.actionCount??0,i.startTime??Date.now(),i.isPaused??!1),e({success:!0});break}case"STOP_CAPTURING":rt(),e({success:!0});break;case"PAUSE_CAPTURING":j(),e({success:!0});break;case"RESUME_CAPTURING":st(),e({success:!0});break;default:e({success:!1})}return!1});et();})();
